package router

import (
	"PengaduanMasyarakat/controller/masyarakatcontroller"
	"PengaduanMasyarakat/controller/pengaduancontroller"
	"PengaduanMasyarakat/middleware"
	"github.com/gin-gonic/gin"
)

func SetupRouter() *gin.Engine {
	router := gin.Default()

	// User group
	users := router.Group("/users")
	{
		users.POST("/register", masyarakatcontroller.Register)
		users.POST("/login", masyarakatcontroller.Login)
		users.PUT("/", masyarakatcontroller.Update)
		users.DELETE("/", masyarakatcontroller.Delete)
	}

	// aduan group
	aduan := router.Group("/aduan")
	aduan.Use(middleware.AuthMiddleware())
	{
		aduan.POST("/", pengaduancontroller.CreateAduan)
		aduan.GET("/", pengaduancontroller.GetAll)
		aduan.GET("/:id", pengaduancontroller.GetOne)
		aduan.PUT("/:id", pengaduancontroller.UpdateAduan)
		aduan.DELETE("/:id", pengaduancontroller.DeleteAduan)
	}

	return router
}
