package models

import "time"

type Pengaduan struct {
	ID               uint   `gorm:"primaryKey"`
	JudulPengaduan   string `gorm:"type:varchar(200);not null"`
	IsiPengaduan     string `gorm:"type:text;not null"`
	Status           string `gorm:"type:varchar(20);not null"`
	MasyarakatID     uint   `gorm:"not null"`
	TanggalPengaduan time.Time
}
