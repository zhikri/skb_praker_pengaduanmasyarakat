package models

import "time"

type Masyarakat struct {
	ID           uint   `gorm:"primaryKey"`
	Nama         string `gorm:"type:varchar(50);not null"`
	Email        string `gorm:"type:varchar(50);not null"`
	Username     string `gorm:"type:varchar(150);not null"`
	Password     string `gorm:"type:text;not null"`
	Tlp          string `gorm:"not null"`
	PhotoProfile string `gorm:"type:text;not null" json:"profile_image_url"`
	CreatedAt    time.Time
	UpdatedAt    time.Time

	Pengaduan []Pengaduan `gorm:"foreignKey:MasyarakatID;constraint:OnDelete:CASCADE"`
}
