package main

import (
	"PengaduanMasyarakat/database"
	"PengaduanMasyarakat/router"
)

func main() {
	database.ConnectDatabase()
	r := router.SetupRouter()

	r.Run()
}
