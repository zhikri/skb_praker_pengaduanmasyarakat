package database

import (
	"PengaduanMasyarakat/models"
	"gorm.io/gorm"
)
import "gorm.io/driver/postgres"

var DB *gorm.DB

func ConnectDatabase() {
	dsn := "host=localhost user=postgres password=postgres dbname=skb_praker port=5432 sslmode=disable TimeZone=Asia/Jakarta"
	database, err := gorm.Open(postgres.Open(dsn))

	if err != nil {
		panic("gagal koneksi ke database")
	}

	database.AutoMigrate(&models.Masyarakat{}, &models.Pengaduan{})

	DB = database

}
