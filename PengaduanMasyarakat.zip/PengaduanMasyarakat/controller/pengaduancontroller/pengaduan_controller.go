package pengaduancontroller

import (
	"PengaduanMasyarakat/config"
	"PengaduanMasyarakat/database"
	"PengaduanMasyarakat/models"
	"github.com/gin-gonic/gin"
	"net/http"
)

func GetAll(c *gin.Context) {
	claims, exists := c.Get("claims")
	if !exists {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Klaim jwt tidak tersedia"})
		return
	}

	userID := claims.(*config.JWTClaim).ID // Mendapatkan ID pengguna dari klaim JWT

	var aduan []models.Pengaduan
	// Mengambil semua social media dari database
	if err := database.DB.Find(&aduan).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch aduan"})
		return
	}

	var userAduan []models.Pengaduan
	// Memfilter social media berdasarkan ID pengguna
	for _, sc := range aduan {
		if sc.MasyarakatID == userID {
			userAduan = append(userAduan, sc)
		}
	}

	c.JSON(http.StatusOK, userAduan)
}

func GetOne(c *gin.Context) {
	id := c.Param("id")

	// Mencari aduan berdasarkan ID dalam database
	var aduan models.Pengaduan
	if err := database.DB.First(&aduan, id).Error; err != nil {
		// Jika aduan tidak ditemukan, kirim respons dengan status Not Found (404)
		c.JSON(http.StatusNotFound, gin.H{"error": "aduan tidak ditemukan"})
		return
	}

	// Mengembalikan aduan dalam respons JSON
	c.JSON(http.StatusOK, aduan)
}

func CreateAduan(c *gin.Context) {
	var aduan models.Pengaduan
	if err := c.ShouldBindJSON(&aduan); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	claims, exists := c.Get("claims")
	if !exists {
		// Jika klaim tidak ada dalam konteks, tangani kesalahan sesuai kebutuhan Anda
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Klaim tidak tersedia"})
		return
	}

	//Validasi judul pengaduan
	if aduan.JudulPengaduan == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Judul Pengaduan Diperlukan!"})
		return
	}

	// Validasi isi
	if aduan.IsiPengaduan == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Isi Pengaduan harus ada!"})
		return
	}

	// Mengakses nilai spesifik dalam klaim
	userID := claims.(*config.JWTClaim).ID
	aduan.MasyarakatID = userID
	if err := database.DB.Create(&aduan).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create social media"})
		return
	}

	c.JSON(http.StatusCreated, aduan)
}

func UpdateAduan(c *gin.Context) {
	claims, exists := c.Get("claims")
	if !exists {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Klaim tidak tersedia"})
		return
	}
	// Mendapatkan ID Aduan dari parameter URL
	id := c.Param("id")

	// Mencari Aduan yang akan diupdate dalam database
	var aduan models.Pengaduan
	if err := database.DB.First(&aduan, id).Error; err != nil {
		// Jika aduan tidak ditemukan, kirim respons dengan status Not Found (404)
		c.JSON(http.StatusNotFound, gin.H{"error": "aduan tidak ditemukan"})
		return
	}

	// Bind JSON dari body permintaan ke struct Comment
	if err := c.ShouldBindJSON(&aduan); err != nil {
		// Jika terjadi kesalahan saat binding JSON, kirim respons dengan status Bad Request (400)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	userID := claims.(*config.JWTClaim).ID
	aduan.MasyarakatID = userID
	// Update social media dalam database
	if err := database.DB.Save(&aduan).Error; err != nil {
		// Jika terjadi kesalahan saat menyimpan perubahan ke database, kirim respons dengan status Internal Server Error (500)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Gagal memperbarui aduan"})
		return
	}

	// Mengembalikan Aduan yang telah diupdate dalam respons JSON
	c.JSON(http.StatusOK, aduan)
}

func DeleteAduan(c *gin.Context) {
	id := c.Param("id")

	// Mencari social media yang akan dihapus dalam database
	var aduan models.Pengaduan
	if err := database.DB.First(&aduan, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Aduan tidak ditemukan"})
		return
	}

	// Menghapus aduan dari database
	if err := database.DB.Delete(&aduan).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Gagal menghapus aduan"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "aduan berhasil dihapus"})
}
